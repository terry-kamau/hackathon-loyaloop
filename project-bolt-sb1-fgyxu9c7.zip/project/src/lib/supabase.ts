import { createClient } from '@supabase/supabase-js';

const supabaseUrl = 'https://ukohdwadahmtnpxztgtm.supabase.co';
const supabaseAnonKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InVrb2hkd2FkYWhtdG5weHp0Z3RtIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDgyODA1MTcsImV4cCI6MjA2Mzg1NjUxN30.F8UeYX_z3uDMWyhWMUL_LHq-CH2q0q7NDIOI9VkaoDA';

export const supabase = createClient(supabaseUrl, supabaseAnonKey);