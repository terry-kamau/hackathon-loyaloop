import { useState } from 'react'
import { supabase } from './lib/supabase'
import confetti from 'canvas-confetti'
import { Coffee, Shirt, Scissors } from 'lucide-react'

const rewardSound = new Audio('https://assets.mixkit.co/sfx/preview/mixkit-achievement-bell-600.mp3')

const REWARD_TYPES = [
  { type: 'FREE_COFFEE', icon: Coffee, label: 'Free Coffee' },
  { type: 'FREE_TSHIRT', icon: Shirt, label: 'Salon T-Shirt' },
  { type: '50_DISCOUNT', icon: Scissors, label: '50% Off Next Visit' }
]

export default function App() {
  const [phone, setPhone] = useState('')
  const [message, setMessage] = useState('')

  const checkIn = async () => {
    if (!phone.trim()) {
      setMessage('🚫 Please enter a valid phone number.')
      return
    }
    setMessage('⏳ Checking in...')

    try {
      // Get or create user
      let { data: users, error } = await supabase
        .from('users')
        .select('*')
        .eq('phone', phone)
        .limit(1)

      if (error) throw error

      let user = users?.[0]

      if (!user) {
        const { data: newUsers, error: insertError } = await supabase
          .from('users')
          .insert([{ phone }])
          .select()

        if (insertError) throw insertError
        user = newUsers[0]
      }

      // Add visit
      const { error: visitError } = await supabase
        .from('visits')
        .insert([{ user_id: user.id }])

      if (visitError) throw visitError

      // Count visits
      const { count } = await supabase
        .from('visits')
        .select('*', { count: 'exact', head: true })
        .eq('user_id', user.id)

      let msg = `✅ Visit #${count} recorded for ${phone}`

      // Every 5th visit => reward
      if (count && count % 5 === 0) {
        const rewardType = REWARD_TYPES[Math.floor(Math.random() * REWARD_TYPES.length)].type
        const { error: rewardError } = await supabase
          .from('rewards')
          .insert([{ user_id: user.id, reward_type: rewardType }])
        if (rewardError) throw rewardError

        confetti({ 
          particleCount: 150, 
          spread: 90, 
          origin: { y: 0.6 },
          colors: ['#FF69B4', '#FFB6C1', '#FFC0CB'] 
        })
        rewardSound.play()
        msg += '\n🎉 Congrats! You earned a reward!'
      }

      // Get rewards with types
      const { data: rewards } = await supabase
        .from('rewards')
        .select('*')
        .eq('user_id', user.id)

      const rewardCounts = rewards?.reduce((acc, reward) => {
        acc[reward.reward_type] = (acc[reward.reward_type] || 0) + 1
        return acc
      }, {})

      msg += '\n\n🏅 Your Rewards:'
      REWARD_TYPES.forEach(({ type, label }) => {
        if (rewardCounts?.[type]) {
          msg += `\n${label}: ${rewardCounts[type]}`
        }
      })

      setMessage(msg)
    } catch (error) {
      setMessage('❌ Something went wrong, please try again.')
      console.error(error)
    }
  }

  return (
    <div className="min-h-screen bg-pink-50 flex items-center justify-center p-6">
      <div className="bg-white p-8 rounded-xl shadow-lg max-w-md w-full text-center">
        <h1 className="text-3xl font-bold text-pink-600 mb-6">✨ Salon Rewards</h1>
        <input
          type="tel"
          placeholder="Enter phone number"
          value={phone}
          onChange={(e) => setPhone(e.target.value)}
          className="w-full p-3 border-2 border-pink-300 rounded-md mb-4 text-lg focus:outline-none focus:ring-4 focus:ring-pink-200"
        />
        <button
          onClick={checkIn}
          className="w-full bg-pink-500 hover:bg-pink-600 text-white font-semibold py-3 rounded-md transition"
        >
          Check In
        </button>
        <pre className="mt-5 whitespace-pre-wrap text-left text-pink-900 font-semibold">{message}</pre>
      </div>
    </div>
  )
}