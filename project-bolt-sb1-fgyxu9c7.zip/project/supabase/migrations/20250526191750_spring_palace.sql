/*
  # Add reward types for salon

  1. Changes
    - Add reward_type column to rewards table with specific types
    - Add default reward type
*/

ALTER TABLE rewards 
ADD COLUMN IF NOT EXISTS reward_type text DEFAULT 'FREE_COFFEE';

-- Update existing rewards to have a type if they don't already
UPDATE rewards 
SET reward_type = 'FREE_COFFEE' 
WHERE reward_type IS NULL;