/*
  # Fix RLS Policies for Public Access

  1. Changes
    - Add policies to allow public access for creating and reading users
    - Add policies to allow public access for creating and reading visits
    - Add policies to allow public access for creating and reading rewards

  2. Security
    - Maintain existing service role policies
    - Add new policies for public access
*/

-- Users table policies
CREATE POLICY "Allow public to create users"
  ON users
  FOR INSERT
  TO public
  WITH CHECK (true);

CREATE POLICY "Allow public to read users"
  ON users
  FOR SELECT
  TO public
  USING (true);

-- Visits table policies
CREATE POLICY "Allow public to create visits"
  ON visits
  FOR INSERT
  TO public
  WITH CHECK (true);

CREATE POLICY "Allow public to read visits"
  ON visits
  FOR SELECT
  TO public
  USING (true);

-- Rewards table policies
CREATE POLICY "Allow public to create rewards"
  ON rewards
  FOR INSERT
  TO public
  WITH CHECK (true);

CREATE POLICY "Allow public to read rewards"
  ON rewards
  FOR SELECT
  TO public
  USING (true);