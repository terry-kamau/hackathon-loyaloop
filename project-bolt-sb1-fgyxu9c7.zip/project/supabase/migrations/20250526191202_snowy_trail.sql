/*
  # Rename phone_number column to phone

  1. Changes
    - Rename `phone_number` column to `phone` in `users` table to match application code
*/

DO $$ 
BEGIN
  IF EXISTS (
    SELECT 1 
    FROM information_schema.columns 
    WHERE table_name = 'users' 
    AND column_name = 'phone_number'
  ) THEN
    ALTER TABLE users RENAME COLUMN phone_number TO phone;
  END IF;
END $$;